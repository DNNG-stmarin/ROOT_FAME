/*
Trigger analysis:
Author: Stefano Marin
Purpose: Performs an analysis of the triggering system, and outputs the main statistics
*/

#define TriggerAnalysis_cxx

#include "DetectorSystemClass.h"

void DetectorSystemClass::TriggerAnalysis()
{

}
