/*
Author: Stefano Marin
Purpose: Store all the attributes of a fission event to be stored in the tree
Date: May 14th, 2020
*/
